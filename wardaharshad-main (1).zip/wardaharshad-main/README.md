# Programmer Wardah Arshad.
<img src="https://github.com/wardaharshad/wardaharshad/blob/main/Image/hello.gif" width="30"> <br />Hello World, I am <strong>Wardah Arshad</strong>.<br />
I am a self taught Python Programmer.<br/>
I like to work on IoT, AI, and Data Science Projects. <br/>
I am also a Graphic Designer & Video Editor and work as a part-time freelancer. <br/>
Electronics Engineer from NEDUET.
<br/>
<br/>

![github stats](https://github-readme-stats.vercel.app/api?username=wardaharshad&hide=contribs,prs)
![Top Langs](https://github-readme-stats.vercel.app/api/top-langs/?username=wardaharshad&layout=compact&theme=radical)

# My Work and website
-[LinkedIn](https://www.linkedin.com/in/wardah-arshad-4b467021b/)
<br />
-[My Startup](https://www.utech-edu.com)
<br />
